export interface PronosticoHora {
  hora_local: string
  sst_lago_c: number
  t850_c: number
  cizalladura_850_ms: number
  swi?: number
  riesgo?: string
}

const getHoraLocal = (horasDesdeAhora: number) => {
  const fecha = new Date()
  fecha.setHours(fecha.getHours() + horasDesdeAhora)
  return fecha.toLocaleString("es-MX", {
    weekday: "long",
    hour: "2-digit",
    minute: "2-digit",
  })
}

export const mockPronosticoData: PronosticoHora[] = Array.from({ length: 168 }, (_, i) => {
  const variacion = Math.sin(i / 12) * 2
  return {
    hora_local: getHoraLocal(i),
    sst_lago_c: 28 + variacion * 0.5,
    t850_c: 12 - variacion,
    cizalladura_850_ms: 35 + Math.cos(i / 8) * 10,
    swi: -5 + variacion,
    riesgo: "BAJO",
  }
})

export async function fetchPronosticoData(): Promise<PronosticoHora[]> {
  try {
    const response = await fetch("/pronostico.json", { cache: "no-store" })
    if (!response.ok) throw new Error("No JSON")
    return await response.json()
  } catch (error) {
    return mockPronosticoData
  }
}
