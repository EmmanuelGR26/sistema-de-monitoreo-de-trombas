"use client"

import { useEffect } from "react"
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from "react-leaflet"
import L from "leaflet"
import type { RiskResult } from "@/lib/swi"
import { RISK_META } from "@/lib/swi"

const CHAPALA: [number, number] = [20.25, -103.2]

/** Corrige el tamaño del mapa cuando el contenedor flex termina de dimensionarse. */
function ResizeFix() {
  const map = useMap()
  useEffect(() => {
    const fix = () => {
      map.invalidateSize()
      map.setView(CHAPALA, 11)
    }
    // Varios reintentos para cubrir el montaje del layout flex.
    const timers = [0, 200, 500, 900].map((d) => setTimeout(fix, d))
    window.addEventListener("resize", fix)

    return () => {
      timers.forEach(clearTimeout)
      window.removeEventListener("resize", fix)
    }
  }, [map])
  return null
}

function buildIcon(color: string) {
  return L.divIcon({
    className: "",
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    popupAnchor: [0, -14],
    html: `
      <span style="
        display:flex;align-items:center;justify-content:center;
        width:22px;height:22px;border-radius:50%;
        background:${color};
        box-shadow:0 0 0 4px color-mix(in oklch, ${color} 30%, transparent),
                   0 0 14px ${color};
        border:2px solid #0a0f1a;
      "></span>`,
  })
}

export default function MapView({
  result,
  timeLabel,
}: {
  result: RiskResult
  timeLabel?: string
}) {
  const color = RISK_META[result.level].token
  // radio de la zona de convergencia crece con el riesgo
  const radius = 1500 + result.score * 35

  return (
    <MapContainer
      center={CHAPALA}
      zoom={11}
      scrollWheelZoom
      style={{ height: "100%", width: "100%" }}
      zoomControl
    >
      <ResizeFix />
      <TileLayer
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>'
      />

      <Circle
        center={CHAPALA}
        radius={radius}
        pathOptions={{
          color,
          fillColor: color,
          fillOpacity: 0.12,
          weight: 1.5,
          dashArray: "6 6",
        }}
      />

      <Marker position={CHAPALA} icon={buildIcon(color)}>
        <Popup>
          <strong style={{ letterSpacing: "0.05em" }}>ZONA DE CONVERGENCIA</strong>
          <br />
          Lat 20.25 · Lon -103.20
          <br />
          Índice SWI: {result.score}/100
          {timeLabel ? (
            <>
              <br />
              {timeLabel}
            </>
          ) : null}
        </Popup>
      </Marker>
    </MapContainer>
  )
}
