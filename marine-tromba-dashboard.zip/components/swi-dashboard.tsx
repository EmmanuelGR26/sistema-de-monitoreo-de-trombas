"use client"

import { useMemo, useState, useEffect } from "react"
import dynamic from "next/dynamic"
import { Loader2, Layers, Calendar } from "lucide-react"
import { ControlPanel } from "@/components/control-panel"
import { Slider } from "@/components/ui/slider"
import { computeRisk, RISK_META, type SwiInputs } from "@/lib/swi"
import { fetchPronosticoData, type PronosticoHora } from "@/lib/mock-data"

const MapView = dynamic(() => import("@/components/map-view"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-card text-muted-foreground">
      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
      <span className="font-mono text-xs uppercase tracking-widest">Cargando radar…</span>
    </div>
  ),
})

export function SwiDashboard() {
  const [data, setData] = useState<PronosticoHora[]>([])
  const [timeIndex, setTimeIndex] = useState(0)

  // Cargar datos (reales o simulados) al iniciar
  useEffect(() => {
    fetchPronosticoData().then(setData)
  }, [])

  const currentData = data[timeIndex] || null

  const inputs: SwiInputs = useMemo(() => {
    if (!currentData) return { sst: 28, t850: 12, wind: 35 }
    return {
      sst: currentData.sst_lago_c,
      t850: currentData.t850_c,
      wind: currentData.cizalladura_850_ms,
    }
  }, [currentData])

  const result = useMemo(() => computeRisk(inputs), [inputs])
  const meta = RISK_META[result.level]

  // Pantalla de carga mientras se obtienen los datos iniciales
  if (!currentData) {
    return (
      <div className="flex h-dvh w-full items-center justify-center bg-background text-muted-foreground">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
        <span className="font-mono text-xs uppercase tracking-widest">Cargando pronóstico...</span>
      </div>
    )
  }

  return (
    <main className="flex h-dvh flex-col overflow-hidden lg:flex-row">
      <ControlPanel inputs={inputs} onChange={() => {}} />

      <section className="relative flex-1 flex flex-col">
        <div className="flex-1 relative">
          
          {/* HUD superior con la fecha dinámica */}
          <div className="pointer-events-none absolute inset-x-0 top-0 z-[1000] flex items-center justify-between gap-2 p-3">
            <div className="pointer-events-auto flex items-center gap-2 rounded-lg border border-border bg-card/80 px-3 py-2 backdrop-blur">
              <Calendar className="h-4 w-4 text-primary" aria-hidden="true" />
              <span className="font-mono text-xs tabular-nums text-foreground capitalize">
                {currentData.hora_local}
              </span>
            </div>

            <div
              className="pointer-events-auto flex items-center gap-2 rounded-lg border bg-card/80 px-3 py-2 backdrop-blur"
              style={{ borderColor: `color-mix(in oklch, ${meta.token} 50%, transparent)` }}
            >
              <Layers className="h-4 w-4" style={{ color: meta.token }} aria-hidden="true" />
              <span
                className="font-mono text-xs font-semibold uppercase tracking-wider"
                style={{ color: meta.token }}
              >
                Alerta {meta.label}
              </span>
            </div>
          </div>

          <div className="h-full w-full">
            <MapView result={result} />
          </div>
        </div>

        {/* Panel del Deslizador (Slider) */}
        <div className="p-6 bg-card border-t z-[1001] shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
            <div className="max-w-3xl mx-auto flex flex-col gap-3">
                <div className="flex justify-between text-xs font-mono font-semibold text-muted-foreground">
                    <span>AHORA</span>
                    <span>PRONÓSTICO 168 HORAS (+7 DÍAS)</span>
                </div>
                <Slider 
                    defaultValue={[0]} 
                    max={167} 
                    step={1} 
                    onValueChange={(val) => setTimeIndex(val[0])}
                    className="cursor-pointer"
                />
                <div className="text-center text-xs text-muted-foreground mt-1">
                  Hora seleccionada: <span className="font-medium text-foreground capitalize">{currentData.hora_local}</span> (+{timeIndex} h)
                </div>
            </div>
        </div>
      </section>
    </main>
  )
}
